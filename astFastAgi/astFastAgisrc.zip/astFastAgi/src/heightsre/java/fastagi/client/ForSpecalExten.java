package heightsre.java.fastagi.client;

import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiRequest;
import org.asteriskjava.fastagi.BaseAgiScript;

// this web service is for special extension for super cell
public class ForSpecalExten extends BaseAgiScript {

	@Override
	public void service(AgiRequest arg0, AgiChannel arg1) throws AgiException {
		// TODO Auto-generated method stub
		
		String chann = getVariable("CHANNEL");
		String exten = getVariable("EXTEN");
		//This call is from outside
		if (chann.startsWith("SIP/xo") || chann.startsWith("Transfered/SIP/xo"))
		{
			setVariable("CDR(accountcode)", "IN");// set it as incoming
			setVariable("SPDIALPAR", "M(cell-screen)");
			setVariable("__CSCALLERID", getVariable("CALLERID(num)"));
		//	streamFile("custom/legalfirst2"); // play legal prompt
			
		} else
		{
			// this call is from internal
		//	String unid = getVariable("UNIQUEID");
		//	setVariable("CDR(accountcode)", "OUT");  // set it as outbound call
		//	setVariable("__OUTBOUNDREC", "outbound" + unid);
		//	setVariable("SPDIALPAR", "M(trunk-dialout)"); // go to macro trunk-dialout for monitoring
		//	setVariable("CDR(userfield)", "outbound" + unid);
		}
			
		String[] opts = new String[3];
		opts[0] = getVariable("EXTEN");
		opts[1] = getVariable("CALLERID(name)");
		opts[2] = getVariable("CALLERID(num)");
		
		String cmd = "GETSPECIALCELL";
		
		String url = "http://www.heightsre.com/Examples/TEST/heightscalls.nsf/AstPortal";
	    
		NotesWSClient wsclient = new NotesWSClient(url);
		
		String[] res = wsclient.generalCommand(cmd, opts);
		
		setVariable("CELLPHONE", res[0]);
		
		
		String exStatus = res[1];
		String punched = res[2];
		String trstrategy = res[3];
		String coext = res[4];
		String empname = res[5];
		
		String phones = res[6];
		
		
		if (!phones.equals("NONE"))
		{
		String[] vecphones = phones.split(":");
		
		setVariable("PHONENUM", "" + vecphones.length);
		
		for (int i=0; i<vecphones.length; i++)
		{
			setVariable("PH" + (i+1), vecphones[i]);
			
			
		}
		
		}
		
		
		
		int trs = Integer.parseInt(trstrategy);
		
		
		switch(trs) 
		{
		case 0:  // extension => cell
		/*	String dialstatus = getVariable("DIALSTATUS");
			if (dialstatus.equals("NOANSWER"))
			{
				setContext("special-vm");
				setExtension(exten);
				setPriority("1");
				
			}
			*/
			
			
			break;
		
		case 1:  // extension => vm/cell
			
			if ((punched.equals("IN")) && !exStatus.equals("UNAVAILABLE"))
			{
				setContext("special-vm");
				setExtension(exten);
				setPriority("1");
			}
			
			String callinmode = getVariable("INCALLMODE");
			
			if (callinmode.equals("directin"))
			{
				setContext("special-vm");
				setExtension(exten);
				setPriority("1");
			}
			
			break;
			
			
		case -1:
			
			setContext("special-vm");
			setExtension(exten);
			setPriority("1");
			
			break;
			
			
      case 2:
			
			setContext("extnoansermenu");
			setExtension("s");
			setPriority("1");
			setVariable("LCEXT",exten);
			setVariable("COEXT", coext);
			setVariable("EMPNAME",empname);
			
			break;	
			
			
      case -5:
			
			String[] exts = coext.split(":");
    	  
    	  
    	  
    	    ;
			
			
			if (exts[0].equals("NONE") && exts[1].equals("NONE"))
			{	 setContext("special-vm");
			     setExtension(exten);
			     setPriority("1");
			     break;
			}else
			{
				if (exts[0].equals("NONE"))
				{
					 setContext("ivr-2");
				     setExtension(exts[1]);
				     setPriority("1");
				     break;
					
				}
				if (exts[1].equals("NONE"))
				{
					
					 setContext("ivr-2");
				     setExtension(exts[0]);
				     setPriority("1");
					
					 break;
					
				}
				
				
				
				setContext("absencetransfer");
				setExtension("s");
				setPriority("1");
				setVariable("LCEXT",exten);
				setVariable("TRAN1", exts[0]);
				setVariable("TRAN2", exts[1]);
				setVariable("EMPNAME",empname);
				
				
				break;
				
			}
			
			
			
			
			
			
					
			
			
		default:  // extension => cell
	
		}
		
		
		
		
	
		
		
		
		
		
		

	}

}
