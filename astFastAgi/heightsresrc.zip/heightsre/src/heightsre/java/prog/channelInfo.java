package heightsre.java.prog;
import java.util.*;

public class channelInfo {
	public String unid;
	public Date startdate;
	public String chann;
	public Date startDial;

}
